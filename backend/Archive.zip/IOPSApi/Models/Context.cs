﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace IOPSApi.Models
{
    public class Context
    {
        [Key]
        public string NomContext { get; set; }
        public ICollection<Inscription> Inscriptions { get; set; }
    } 
}
 